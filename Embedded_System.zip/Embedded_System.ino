/////////////////////////////////////////////////CHOOSE BOARD/////////////////////////////////////////////////

#pragma region ShieldSelection

#include "src/lib/boards.h"

// #define USING_BOARD MEGA_OCTA_PTH_MK_I
// #define USING_BOARD MEGA_STACK_DADOS_ACIONAMENTO_2019
// #define USING_BOARD MEGA_STACK_DADOS_ACIONAMENTO_2020
// #define USING_BOARD ESP_ESSENTIALS_2025
// #define USING_BOARD ESP_ESSENTIALS_2026
#define USING_BOARD ESP_MAIN_SMD_2026
// #define USING_BOARD ESP_JOHN_SI_SMD_2026

#include "src/lib/pinos.h"

#pragma endregion

//////////////////////////////////////////////////CHOOSE MODE//////////////////////////////////////////////////

#pragma region ModeSelection

#include "src/lib/modes.h"

#define USING_MODE MODE_LANCAMENTO
// #define USING_MODE MODE_ELEVADOR
// #define USING_MODE MODE_ASPIRADOR

#include "src/lib/pressets.h"

#pragma endregion

/////////////////////////////////////////////////CONFIGURATION/////////////////////////////////////////////////

#pragma region Configurations

#define BaudRate 115200

#define USE_GY80 (0)						//Use GY80 module
#define USE_GY91 (0)						//Use GY91 module
#define USE_GY912 (0)						//Use GY912 module

#define SDCard (0)							//Use SD card
#define GPSmode (0)							//Use GPS
#define LoRamode (0)						//Serial mode for transmission on LoRa module
#define TalkingBoard (0)					//When two boards are connected for redundancy system
#define BuZZ (0)							//Buzzer mode
#define ForceSysC (0)

#define PRINT (1)							//Print or not things on Serial

// #define PROJECT_NAME CURRENT_MODE_PROJECT_NAME

/**************************** GY80 ****************************/
#define USE_BMP085 (USE_GY80 || 0)			//Use BMP085 sensor
#define USE_ADXL345 (USE_GY80 || 0)			//Use ADXL345 sensor
#define USE_L3G4200D (USE_GY80 || 0)		//Use L3G4200D sensor
#define USE_HMC5883 (USE_GY80 || 0)			//Use HMC5883 sensor

/**************************** GY91 ****************************/
#define USE_BMP280 (USE_GY91 || 0)			//Use BMP280 sensor
#define USE_MPU9250_ACCEL (USE_GY91 || 0)	//Use MPU9250 sensor, accelerometer
#define USE_MPU9250_GYRO (USE_GY91 || 0)	//Use MPU9250 sensor, gyroscope
#define USE_AK8963 (USE_GY91 || 0)			//Use AK8963 sensor

/**************************** GY912 ****************************/
#define USE_BMP388 (USE_GY912 || 1)			//Use BMP280 sensor
#define USE_ICM20948_ACCEL (USE_GY912 || 1)	//Use ICM20948 sensor, accelerometer
#define USE_ICM20948_GYRO (USE_GY912 || 0)	//Use ICM20948 sensor, gyroscope
// #define USE_AK8963 (USE_GY912 || 0)			//Use AK8963 sensor

/************************** 9DoF IMU **************************/
#define USE_BARO (USE_BMP085 || USE_BMP280 || USE_BMP388)				// Use any Barometer
#define USE_ACCEL (USE_ADXL345 || USE_MPU9250_ACCEL || USE_ICM20948_ACCEL)	// Use any Accelerometer
#define USE_GYRO (USE_L3G4200D || USE_MPU9250_GYRO)		// Use any Gyroscope
#define USE_MAGN (USE_HMC5883 || USE_AK8963)			// Use any Magnetometer

/**************************** LoRa ****************************/

#define USE_LoRa_CONTIGUOUS (LoRamode && 1)		// Force data columns to always exist

#define USE_LoRa_DORJI (LoRamode && defined(BOARD_HAS_LoRa_DORJI))		// Dorji LoRa Module (2019 and before)
#define USE_LoRa_E32 (LoRamode && defined(BOARD_HAS_LoRa_E32))		// E32 LoRa Module (2019 and before)

#define USE_LoRa_E32_settable (USE_LoRa_E32 && 0)

#define USE_LoRa_KEYVALUE (LoRamode && 1)	// Send LoRa data Using Key-value pair

/*************************** Others ***************************/

#define ApoGee (USE_BARO && 1)				//Detection of apogee

#define RBF (0)								//Revome Before Flight
#define WU (ApoGee && 1)					//Wait Until Directives
#define WUF (WU && 1)						//Wait Until Flight
#define WUPS (WU && 1)						//Wait Until Pressure Stabilize

#define ACT_BUZZER (BuZZ && 1)				//Active buzzer in hardware
#define PSS_BUZZER (BuZZ && 0)				//Passive buzzer in hardware
#define MORSE_MSG (BuZZ && 1)				//Morse beeping
#define BEEPING (BuZZ && 0)					//Buzzer mode

#define BlinkBuzzer (BuZZ && 0)
#define RGB (0)								//RGB LED board

#define AnyDeploy (ApoGee && defined(BOARD_HAS_IGN_1) && 0)				//Any Parachute Deployment
#define DualDeploy (AnyDeploy && defined(BOARD_HAS_IGN_2) && 1)			//Dual Parachute Deployment
#define BackupDeploy (AnyDeploy && defined(BOARD_HAS_IGN_3) && defined(BOARD_HAS_IGN_4) && 1)				//Redundancy mode

#define DELAYED_MAIN (AnyDeploy && 1)			//Aways delay main deployment

/*
#define ELEVATOR (0)
*/

#define PbarT (PRINT && USE_BARO && 1)		//Print barometer temperature data
#define PbarP (PRINT && USE_BARO && 1)		//Print barometer pressure data

#define PaclX (PRINT && USE_ACCEL && 1)		//Print accelerometer X axis data
#define PaclY (PRINT && USE_ACCEL && 1)		//Print accelerometer Y axis data
#define PaclZ (PRINT && USE_ACCEL && 1)		//Print accelerometer Z axis data

#define PgirX (PRINT && USE_GYRO && 1)		//Print gyroscope x axis data
#define PgirY (PRINT && USE_GYRO && 1)		//Print gyroscope Y axis data
#define PgirZ (PRINT && USE_GYRO && 1)		//Print gyroscope Z axis data

#define PmagX (PRINT && USE_MAGN && 1)		//Print magnetometer x axis data
#define PmagY (PRINT && USE_MAGN && 1)		//Print magnetometer Y axis data
#define PmagZ (PRINT && USE_MAGN && 1)		//Print magnetometer Z axis data

#define papgI (PRINT && ApoGee && 1)		//Print MonoDeploy.info of every instance
#define PapgW (PRINT && ApoGee && 1)		//Print apogee information when detected
#define PapgH (PRINT && ApoGee && 1)		//Print altimeter data
#define PapgB (PRINT && ApoGee && 1)		//Print altimeter base
#define PapgP (PRINT && ApoGee && 0)		//Print current apogee information
#define PapgA (PRINT && ApoGee && 1)		//Print apogee alpha
#define PapgS (PRINT && ApoGee && 1)		//Print apogee sigma
#define PapgM (PRINT && ApoGee && 0)		//Print apogee sigma max

#define Pgps (PRINT && GPSmode && 1)		//Print GPS informations
#define Psep (PRINT && 0)					//Print visual separator

#define Tcom (PRINT && 1)					//Print time counter
#define Lcom (PRINT && 0)					//Print loop counter
#define Ncom (PRINT && 0)					//Print eachN counter
#define Ps_n (PRINT && 0)					//Print SYSTEM_n

#define PWMapg (ApoGee && 1)				//Show the apogee coefficient in a LED

#define PERF_Tcom_print (0)				//Print time counter every 100 iterations (for performance tests)

#define COMmode (PRINT || LoRamode)
#define WIREmode (USE_BARO || USE_ACCEL || USE_GYRO || USE_MAGN)
#define SYSTEM_n (uint8_t(SDCard)+uint8_t(USE_BARO)+uint8_t(USE_ACCEL)+uint8_t(USE_GYRO)+uint8_t(USE_MAGN)+uint8_t(GPSmode)+uint8_t(ApoGee)+uint8_t(DualDeploy)+uint8_t(BackupDeploy)+uint8_t(DualDeploy && BackupDeploy))

#pragma endregion

/////////////////////////////////////////////////////objects///////////////////////////////////////////////////

#pragma region Declarations

#include "src/lib/Classes.h"

#if USE_BARO
#if 1 < ((USE_BMP085) + (USE_BMP280) + (USE_BMP388))
#error: Múltiplos barômetros definidos
#elif USE_BMP085
#include "src/lib/BMP085/BMP085.h" // Barometro BMP085
BMP085 baro;									//Barometer object declaration
#elif USE_BMP280
#include "src/lib/BMP280/BMP280.h" // Barometro BMP280
BMP280 baro;									//Barometer object declaration
#elif USE_BMP388
#include "src/lib/BMP388/BMP388.h" // Barometro BMP388
BMP388 baro;									//Barometer object declaration
#endif // USE_BMP085 / USE_BMP280
//MovingAverage MM_baro[2]{ (2),(2) };		//Array declaration of the moving average filter objects
float MM_baro[2]{};
bool baroHasData = false;
#endif // USE_BARO

#if ApoGee
#include "src/lib/Apogeu/Apogeu.h" // Processamento de altitude e deteccao de apogeu

Apogeu apg(10, 15, 50);						//Apogee checker object declaration
#define LapsMaxT 5							//Maximum time of delay until emergency state declaration by the delay in sensor response. (seconds)
#define EM_mainN_DELAY 60					// Seconds before forced deployment


#if AnyDeploy
#include "src/lib/MonoDeploy/MonoDeploy.h" // Acionamento de paraquedas simples

#if DualDeploy
/*
#if ELEVATOR
#define p2h 15								//Height to main parachute
#else
#define p2h 450								//Height to main parachute
#endif // ELEVATOR
*/

#define EM_drogN_DELAY 10					// Seconds before forced deployment

#endif // DualDeploy

#if BackupDeploy
#define sysDelay 2.5
#define EM_mainB_DELAY 65					// Seconds before forced deployment

#if DELAYED_MAIN
#define sysDelay_main 1.0
#endif // DELAYED_MAIN

#if DualDeploy
/*
#if ELEVATOR
#define p2h_D 10							//Height to main parachute on redundance mode
#else
#define p2h_D 400							//Height to main parachute on redundance mode
#endif // ELEVATOR
*/

#define EM_drogB_DELAY 15					// Seconds before forced deployment
#endif // DualDeploy

#endif // BackupDeploy


// #define pins_drogN (36, 68)  /*act1*/
// #define pins_drogB (61, 62)  /*act2*/
// //#define pins_mainN (8, 40, 20, 1)  /*act3*/
// #define pins_mainN (46, 56)  /*act3*/
// #define pins_mainB (55, 58)  /*act4*/

// #define pins_drogN (A0, A1) /*act1*/
// #define pins_drogB (A2, A3) /*act2*/
// #define pins_mainN (A4, A5) /*act3*/
// #define pins_mainB (A6, A7) /*act4*/

#define pins_drogN (IGN_1, HEAL_1) /*act1*/
#define pins_drogB (IGN_2, HEAL_2) /*act2*/
#define pins_mainN (IGN_3, HEAL_3) /*act3*/
#define pins_mainB (IGN_4, HEAL_4) /*act4*/


struct Recovery
{
	static MonoDeploy mainN;

#if DualDeploy
	static MonoDeploy drogN;
#endif // DualDeploy

#if BackupDeploy
	static MonoDeploy mainB;

#if DualDeploy
	static MonoDeploy drogB;
#endif // DualDeploy

#endif // BackupDeploy
	static bool begin()
	{
		bool aux = true;
		aux &= mainN.begin();

#if DualDeploy
		aux &= drogN.begin();
#endif // DualDeploy


#if BackupDeploy
		aux &= mainB.begin();

#if DualDeploy
		aux &= drogB.begin();
#endif // DualDeploy

#endif // BackupDeploy


		return aux;
	}
	static void emergency(bool state)
	{
		if(state) MonoDeploy::sealApogee(true);
		mainN.emergency(state, EM_mainN_DELAY);

		#if DualDeploy
				drogN.emergency(state, EM_drogN_DELAY);
		#endif // DualDeploy

		#if BackupDeploy
				mainB.emergency(state, EM_mainB_DELAY);

		#if DualDeploy
				drogB.emergency(state, EM_drogB_DELAY);
		#endif // DualDeploy

		#endif // BackupDeploy
	}
	static bool getGlobalState()
	{
		bool aux = false;
		aux |= mainN.getGlobalState();

#if DualDeploy
		aux |= drogN.getGlobalState();
#endif // DualDeploy

#if BackupDeploy
		aux |= mainB.getGlobalState();

#if DualDeploy
		aux |= drogB.getGlobalState();
#endif // DualDeploy

#endif // BackupDeploy
		return aux;
	}
	static void refresh()
	{
		mainN.refresh();

#if DualDeploy
		drogN.refresh();
#endif // DualDeploy

#if BackupDeploy
		mainB.refresh();

#if DualDeploy
		drogB.refresh();
#endif // DualDeploy

#endif // BackupDeploy
	}
	static void resetTimer()
	{
		MonoDeploy::resetTimer();
	}
	static void sealApogee(bool apg)
	{
		MonoDeploy::sealApogee(apg);
	}
	static void putHeight(float H)
	{
		MonoDeploy::putHeight(H);
	}
	static bool getApogee()
	{
		return MonoDeploy::getApogee();
	}
} rec;

MonoDeploy Recovery::mainN pins_mainN;

#if DualDeploy
MonoDeploy Recovery::drogN pins_drogN;
#endif // DualDeploy


#if BackupDeploy
MonoDeploy Recovery::mainB pins_mainB;

#if DualDeploy
MonoDeploy Recovery::drogB pins_drogB;
#endif // DualDeploy

#endif // BackupDeploy

#else
	#warning Essa compilacao nao realiza disparo de paraquedas
#endif // AnyDeploy

#endif // ApoGee

/*
#if WUF

#if ELEVATOR
#define WUFheigh 5
#else
#define WUFheigh 50
#endif // ELEVATOR

#endif // WUF
*/

/*
#if WUPS

#if ELEVATOR
#define WUPSdelay 3
#else
#define WUPSdelay 10
#endif // ELEVATOR

#endif // WUPS
*/

#if USE_ACCEL
#if 1 < ((USE_ADXL345) + (USE_MPU9250_ACCEL) + (USE_ICM20948_ACCEL))
#error: Múltiplos acelerômetros definidos
#elif USE_ADXL345
#include "src/lib/ADXL345/ADXL345.h" // Accelerometer ADXL345
ADXL345 accel;									//Accelerometer object declaration
#elif USE_MPU9250_ACCEL
#include "src/lib/MPU9250_ACCEL/MPU9250_ACCEL.h" // Accelerometer MPU9250_ACCEL
MPU9250_ACCEL accel(16);									//Accelerometer object declaration
#elif USE_ICM20948_ACCEL
#include "src/lib/ICM20948_ACCEL/ICM20948_ACCEL.h" // Accelerometer MPU9250_ACCEL
ICM20948_ACCEL accel(16);									//Accelerometer object declaration
#endif // USE_ADXL345 / USE_MPU9250_ACCEL
//MovingAverage MM_accel[3]{ (5),(5),(5) };	//Array declaration of the moving average filter objects
float MM_accel[3]{};
#endif // USE_ACCEL

#if USE_GYRO
#if 1 < ((USE_L3G4200D) + (USE_MPU9250_GYRO))
#error: Múltiplos gisroscópios definidos
#elif USE_L3G4200D
#include "src/lib/L3G4200D/L3G4200D.h" // Gyroscope L3G4200D
L3G4200D giro(2000);							//Gyroscope object declaration
#elif USE_MPU9250_GYRO
#include "src/lib/MPU9250_GYRO/MPU9250_GYRO.h" // Gyroscope MPU9250_GYRO
MPU9250_GYRO giro(2000);							//Gyroscope object declaration
#endif // USE_L3G4200D / USE_MPU9250_GYRO
//MovingAverage MM_giro[3]{ (5),(5),(5) };	//Array declaration of the moving average filter objects
float MM_giro[3]{};
#endif // USE_GYRO

#if USE_MAGN
#if 1 < ((USE_HMC5883) + (USE_AK8963))
#error: Múltiplos magnetômetros definidos
#elif USE_HMC5883
#include "src/lib/HMC5883/HMC5883.h" // Magnetometer HMC5883
HMC5883 magn;									//Magnetometer object declaration
#elif USE_AK8963
#include "src/lib/AK8963/AK8963.h" // Magnetometer AK8963
AK8963 magn;									//Magnetometer object declaration
#endif // USE_HMC5883 / USE_AK8963
//MovingAverage MM_magn[3]{ (5),(5),(5) };	//Array declaration of the moving average filter objects
float MM_magn[3]{};
#endif // USE_MAGN

#if SDCard

#include <SPI.h>
#include <SD.h>
#if ARDUINO_ARCH_ESP32
	SPIClass SPI_SD(FSPI);
#endif // ARDUINO_ARCH_ESP32
#include "src/lib/SDCH/SDCH.h" // Auxiliar para gerenciamento de cartao SD

#if ARDUINO_ARCH_ESP32
SDCH SDC(SD_CS_PIN, CURRENT_MODE_PROJECT_NAME, "txt", SPI_SD);						//Declaration of object to help SD card file management
#else
SDCH SDC(SD_CS_PIN, CURRENT_MODE_PROJECT_NAME);						//Declaration of object to help SD card file management
#endif // ARDUINO_ARCH_ESP32
#endif // SDCard

#if GPSmode
#include "src/lib/GyGPS/GyGPS.h" // Auxiliar para GPS
#ifdef ARDUINO_ARCH_ESP32
HardwareSerial GpSSerial(1);
GyGPS GpS(GpSSerial, 0, SERIAL_8N1, RX_GPS_ESP, TX_GPS_ESP);
#else
GyGPS GpS(Serial1, 0);
#endif // ARDUINO_ARCH_ESP32
#endif // GPSmode

#if LoRamode
#if 1 < ((USE_LoRa_DORJI) + (USE_LoRa_E32))
#error: Múltiplos LoRas definidos
#elif USE_LoRa_DORJI
#define LoRaDelay 2.5
#elif USE_LoRa_E32
#define LoRaDelay 2.5
#else
#define LoRaDelay 5
#endif // USE_LoRa_DORJI || USE_LoRa_E32
#ifdef ARDUINO_ARCH_ESP32
HardwareSerial LoRa(2);
#else
HardwareSerial &LoRa(Serial3);
#endif
Helpful LRutil;								//Declaration of helpful object to telemetry system
#define LoRaBaudRate 9600
#if USE_LoRa_E32
#if !defined(M0_LORA_PIN) || !defined(M1_LORA_PIN) || !defined(AUX_LORA_PIN)
#error: Placa selecionada nao utiliza LoRa E32
#endif
#if USE_LoRa_E32_settable

#define FREQUENCY_900
#define LoRa_ADDL 0x17
#define LoRa_ADDH 0x00
#define LoRa_CHAN 0x37

#include "LoRa_E32.h"

LoRa_E32 LoRaConfig(&LoRa, byte(AUX_LORA_PIN), byte(M0_LORA_PIN), byte(M1_LORA_PIN), UART_BPS_RATE(LoRaBaudRate));

void LoRaSetConfig()
{
	ResponseStructContainer c = LoRaConfig.getConfiguration();
	// It's important get configuration pointer before all other operation
	Configuration configuration = *(Configuration*)c.data;
	Serial.println(c.status.getResponseDescription());
	Serial.println(c.status.code);

	//   printParameters(configuration);
	configuration.ADDL = LoRa_ADDL;
	configuration.ADDH = LoRa_ADDH;
	configuration.CHAN = LoRa_CHAN;

	// configuration.OPTION.fec = FEC_0_OFF;
	// configuration.OPTION.fixedTransmission = FT_TRANSPARENT_TRANSMISSION;
	// configuration.OPTION.ioDriveMode = IO_D_MODE_PUSH_PULLS_PULL_UPS;
	// configuration.OPTION.transmissionPower = POWER_17;
	// configuration.OPTION.wirelessWakeupTime = WAKE_UP_1250;

	// configuration.SPED.airDataRate = AIR_DATA_RATE_011_48;
	// configuration.SPED.uartBaudRate = UART_BPS_9600;
	// configuration.SPED.uartParity = MODE_00_8N1;

	// Set configuration changed and set to not hold the configuration
	ResponseStatus rs = LoRaConfig.setConfiguration(configuration, WRITE_CFG_PWR_DWN_SAVE);
	Serial.println(rs.getResponseDescription());
	Serial.println(rs.code);
	//   printParameters(configuration);
	c.close();
}

#endif //USE_LoRa_E32_settable
#endif // USE_LoRa_E32

#if USE_LoRa_KEYVALUE

#define LoRa_KEY_LINE			"L" // Line
#define LoRa_KEY_TIME			"T" // Time
#define LoRa_KEY_LAT			"A" // Latitude
#define LoRa_KEY_LON			"O" // Longitude
#define LoRa_KEY_HOUR			"h" // horas
#define LoRa_KEY_MIN			"n" // minutos
#define LoRa_KEY_PREC			"g" // precisão
#define LoRa_KEY_HEIGTH			"H" // altura atual
#define LoRa_KEY_SD				"s" // SD
#define LoRa_KEY_APG_HEIGHT		"a" // altura Apogeu
#define LoRa_KEY_APG_TIME		"t" // tempo Apogeu
#define LoRa_KEY_MAIN_NORMAL	"M" // Main Normal
#define LoRa_KEY_DROGUE_NORMAL	"D" // Drogue Normal
#define LoRa_KEY_MAIN_BACKUP	"m" // Main Backup
#define LoRa_KEY_DROGUE_BACKUP	"d" // Drogue Backup
#define LoRa_KEY_TEMPERATURE	"c" // Temperatura

#endif // USE_LoRa_KEYVALUE

#endif // LoRamode

#if TalkingBoard
ComProtocol Talk(Serial2, 9600);			//Declaration of communication protocol object
#endif // TalkingBoard

#if ((PRINT) || (PERF_Tcom_print))
#endif // ((PRINT) || (PERF_Tcom_print))

Helpful Gutil;								//Declaration of helpful object to general cases

#if RBF
#define RBFpin 2							//Pin that the RBF system is connected
#endif // RBF

#if RBF || WUF || ForceSysC
unsigned short sysC = 0;
#endif // RBF || WUF || ForceSysC


#if BuZZ

#if BlinkBuzzer
#define buzzPin LED_BUILTIN
#define buzzCmd HIGH
#else
#define buzzCmd LOW							//Buzzer is on in high state
// #define buzzPin A0							//Pin that the buzzer is connected
// #define buzzPin 49							//Pin that the buzzer is connected
#endif // BlinkBuzzer
#endif // BuZZ
#if MORSE_MSG
#include "src/lib/Morse/Morse.h"
#define ALARM_DELAY 10					// Delay after alarm when all systems working properly
#if ACT_BUZZER
MorseAtvBzz mensageiro(buzzPin, buzzCmd, "~ ");
// MorseAtvBzz mensageiro(buzzPin, buzzCmd, "a 1 - . ~ . ^ . < . = . > . [ . ] . { . }");
#elif PSS_BUZZER
Morse mensageiro(buzzPin, "~ ");
// Morse mensageiro(buzzPin, CURRENT_MODE_PROJECT_NAME);
#endif  // ACT_BUZZER / PSS_BUZZER
Helpful Mutil;
#endif // MORSE_MSG
#if BEEPING
#define holdT .1
Helpful beeper;
#endif // BEEPING

#if RGB
#define rPin 7
#define gPin 6
#define bPin 5
#define rgbCmd HIGH
#endif // RGB

#if COMmode
template <typename T> void transmit(T message);
template <typename T> void transmitln(T message);
template <typename T, typename R> void transmit(T message, R value);
template <typename T, typename R> void transmitln(T message, R value);
#endif // COMmode

#pragma endregion


/////////////////////////////////////////////////////SETUP/////////////////////////////////////////////////////

#pragma region Setup
void setup()
{
#if PWMapg
	pinMode(PWMout, OUTPUT);
#endif // PWMapg

#if RBF
	pinMode(RBFpin, INPUT_PULLUP);
#endif // RBF

#if RGB
	pinMode(rPin, OUTPUT);
	pinMode(gPin, OUTPUT);
	pinMode(bPin, OUTPUT);
	digitalWrite(rPin, !rgbCmd);
	digitalWrite(gPin, !rgbCmd);
	digitalWrite(bPin, !rgbCmd);
#endif // RGB

#if AnyDeploy
	rec.begin();
#if DualDeploy
	rec.mainN.setHeightCmd(CURRENT_MODE_P2H_NORMAL);
#endif // DualDeploy
#if DELAYED_MAIN
	rec.mainN.setDelayCmd(sysDelay_main);
#endif // DELAYED_MAIN

#endif // AnyDeploy

#if BackupDeploy

// Main
#if DualDeploy
	rec.mainB.setHeightCmd(CURRENT_MODE_P2H_BACKUP);
#else
#if DELAYED_MAIN
	rec.mainB.setDelayCmd(sysDelay + sysDelay_main);
#else
	rec.mainB.setDelayCmd(sysDelay);
#endif // DELAYED_MAIN
#endif // !DualDeploy

// Drogue
#if DualDeploy
	rec.drogB.setDelayCmd(sysDelay);
#endif // DualDeploy

#endif // BackupDeploy


#if ACT_BUZZER
	pinMode(buzzPin, OUTPUT);
	digitalWrite(buzzPin, !buzzCmd);
#endif // ACT_BUZZER
#if MORSE_MSG
	mensageiro.setup();
	mensageiro.updateMorse();
#endif // MORSE_MSG
#if BEEPING
	beep();
#endif // BEEPING


#if ((PRINT) || (PERF_Tcom_print))
	Serial.begin(BaudRate);
	Serial.println();
#if Ps_n
	Serial.print(F("System number: "));
	Serial.println(SYSTEM_n);
#endif // Ps_n

#endif // Serial

#if LoRamode
#if USE_LoRa_E32_settable
	LoRaConfig.begin();
	LoRaSetConfig();
#else
#if USE_LoRa_E32
	pinMode(M0_LORA_PIN,OUTPUT); digitalWrite(M0_LORA_PIN,LOW);
	pinMode(M1_LORA_PIN,OUTPUT); digitalWrite(M1_LORA_PIN,LOW);
#endif // USE_LoRa_E32
#ifdef ARDUINO_ARCH_ESP32
	LoRa.begin(LoRaBaudRate, SERIAL_8N1, RX_LORA_ESP, TX_LORA_ESP);
#else
	LoRa.begin(LoRaBaudRate);
#endif // ARDUINO_ARCH_ESP32
#endif // LoRamode
#endif  // USE_LoRa_E32_settable

#if GPSmode
	GpS.begin();
	GpS.util.mem = false; // Auxiliar de primeira leitura
	GpS.util.forT(60);
	if (GpS)
	{
		if (GpS.util.oneTime())
		{
#if COMmode
			transmit(F("\nGPS ok "));
			transmit(GpS.getLatitude(), 6);
			transmit(F(", "));
			transmit(GpS.getLongitude(), 6);
#endif // COMmode
		}
	}
	else
	{
#if COMmode
		transmit(F("\nGPS err, waiting signal"));
#endif // COMmode
	}
#endif // GPSmode

#if WIREmode
#if ARDUINO_ARCH_ESP32
	Wire.begin(SDA_I2C_ESP, SCL_I2C_ESP);
#else
	Wire.begin();
#endif // ARDUINO_ARCH_ESP32
#endif // WIREmode

#if USE_BARO
	baro.begin();
	if (baro)
	{
#if USE_BMP280
		for (short i = 0; i < 50; i++) baro.readAll(); // Contornar tempo de estabilização do filtro interno
#endif // USE_BMP280
#if ApoGee
		for (short i = 0; i < 100; i++) if (baro) apg.addZero(baro.getPressure());
		apg.fixZero();
#endif // ApoGee
#if COMmode
		transmit(F("\nBaro ok "));
#endif // COMmode

#if PapgB
		if(apg.getFixZero()){
			Serial.print(F("(Using EEPROM Zero Ref @ < 0x"));
			Serial.print(apg.getEEAddress(), HEX);
			Serial.print(F(" >!) "));
		}

		Serial.print(apg.getZero());
		Serial.println();
#elif PRINT
		Serial.println();
#endif // PRINT

#if LoRamode
#if ApoGee
		if(apg.getFixZero()) {
			LoRa.print(F("(Using EEPROM Zero Ref @ < 0x"));
			LoRa.print(apg.getEEAddress(), HEX);
			LoRa.print(F(" >!) "));
		}
		LoRa.println(apg.getZero());
#endif // ApoGee
		LoRa.println();
#endif // LoRamode

	}
	else
	{
#if COMmode
		transmit(F("\nBaro err"));
#endif // COMmode
	}
#endif // USE_BARO

#if USE_ACCEL
	accel.begin();
	if (accel)
	{
#if COMmode
		transmit(F("\nAccel ok"));
#endif // COMmode
	}
	else
	{
#if COMmode
		transmit(F("\nAccel err"));
#endif // COMmode
	}
#endif // USE_ACCEL

#if USE_GYRO
	giro.begin();
	if (giro)
	{
#if COMmode
		transmit(F("\nGiro ok"));
#endif // COMmode
	}
	else
	{
#if COMmode
		transmit(F("\nGiro err"));
#endif // COMmode
	}
#endif // USE_GYRO

#if USE_MAGN
	magn.begin();
	if (magn)
	{
#if COMmode
		transmit(F("\nMagn ok"));
#endif // COMmode
	}
	else
	{
#if COMmode
		transmit(F("\nMagn err"));
#endif // COMmode
	}
#endif // USE_MAGN

#if AnyDeploy && COMmode
	transmit(rec.mainN.info() ? F("\nIgnMainN ok") : F("\nIgnMainN err"));

#if DualDeploy
	transmit(rec.drogN.info() ? F("\nIgnDrogN ok") : F("\nIgnDrogN err"));
#endif // DualDeploy

#if BackupDeploy
	transmit(rec.mainB.info() ? F("\nIgnMainB ok") : F("\nIgnMainB err"));

#if DualDeploy
	transmit(rec.drogB.info() ? F("\nIgnDrogB ok") : F("\nIgnDrogB err"));
#endif // DualDeploy

#endif // BackupDeploy

#endif // AnyDeploy && COMmode


#if SDCard

#if ARDUINO_ARCH_ESP32
	SPI_SD.begin(SCK_SD_ESP, MISO_SD_ESP, MOSI_SD_ESP, CS_SD_ESP);
#endif // ARDUINO_ARCH_ESP32
	SDC.begin();
	if (SDC)
	{
#if COMmode
		transmit(F("\nSD start OK "));
		transmit(SDC.getFname());
#endif // COMmode

		//////////////////File Header//////////////////

#if ApoGee
		SDC.theFile.print(F("Start at:\t"));
		SDC.theFile.print(apg.getZero());
		SDC.theFile.print(F("\tm"));
		if(apg.getFixZero()) {
			SDC.theFile.print(F("\t(Using EEPROM Zero Ref @ < 0x"));
			SDC.theFile.print(apg.getEEAddress(), HEX);
			SDC.theFile.print(F(" >!) "));
		}
		SDC.theFile.println();
#endif // ApoGee

		///////////////////////////////////////////////

		SDC.theFile.println(F(
			"tempo.s\t"
#if USE_ACCEL
			"mps2.x.accel\tmps2.y.accel\tmps2.z.accel\t"
#endif // USE_ACCEL
#if USE_GYRO
			"dps.x.gyros\tdps.y.gyros\tdps.z.gyros\t"
#endif // USE_GYRO
#if USE_MAGN
			"uT.x.magn\tuT.y.magn\tuT.z.magn\t"
#endif // USE_MAGN
#if USE_BARO
			"c.baro\tpa.baro\t"
#endif // USE_BARO
#if ApoGee
			"m.h.baro\t"
#endif // ApoGee
#if GPSmode
			"lat.GPS\tlon.GPS\tm.h.GPS\tmps.GPS\tsat.GPS\tprec.GPS\t"
#endif // GPSmode
		));

		///////////////////////////////////////////////
/*
		SDC.theFile.println(F(
			"seg\t"
#if USE_ACCEL
			"X\tY\tZ\t"
#endif // USE_ACCEL
#if USE_GYRO
			"X\tY\tZ\t"
#endif // USE_GYRO
#if USE_MAGN
			"X\tY\tZ\t"
#endif // USE_MAGN
#if USE_BARO
			"C\tPascal\t"
#endif // USE_BARO
#if ApoGee
			"m\t"
#endif // ApoGee
#if GPSmode
			"Latitude\tLongitude\tAltitude (m)\tspeed\tSat\tPrec\t"
#endif // GPSmode
		));
*/
		///////////////////////////////////////////////

		SDC.close();
	}
	else
	{

#if COMmode
		transmit(F("\nSD err"));
#endif // COMmode
	}
#endif // SDCard

#if COMmode
		transmitln(F(" "));
#endif // COMmode

	////////////////RBF directive////////////////

#if RBF
	RemoveBefore();
#endif // RBF

	////////////////RBF directive////////////////


#if PbarT || PbarP || PaclX || PaclY || PaclZ || PgirX || PgirY || PgirZ || PmagX || PmagY || PmagZ || PapgW || PapgH || PapgP || PapgA || PapgS || PapgM || Pgps || Psep || Tcom || Lcom || PERF_Tcom_print
	Serial.println(F(
#endif // PbarT || PbarP || PaclX || PaclY || PaclZ || PgirX || PgirY || PgirZ || PmagX || PmagY || PmagZ || PapgW || PapgH || PapgP || PapgA || PapgS || PapgM || Pgps || Psep || Tcom || Lcom || PERF_Tcom_print
#if Lcom
	"loop\t"
#endif // Lcom

#if PERF_Tcom_print
	"temp\t"
#endif // PERF_Tcom_print

#if Tcom
	"tempo.s\t"
#endif // Tcom


#if PaclX
	"mps2.x.accel\t"
#endif // PaclX
#if PaclY
	"mps2.y.accel\t"
#endif // PaclY
#if PaclZ
	"mps2.z.accel\t"
#endif // PaclZ


#if PgirX
	"dps.x.gyros\t"
#endif // PgirX
#if PgirY
	"dps.y.gyros\t"
#endif // PgirY
#if PgirZ
	"dps.z.gyros\t"
#endif // PgirZ


#if PmagX
	"uT.x.magn\t"
#endif // PmagX
#if PmagY
	"uT.y.magn\t"
#endif // PmagY
#if PmagZ
	"uT.z.magn\t"
#endif // PmagZ


#if PbarT
	"c.baro\t"
#endif // PbarT
#if PbarP
	"pa.baro\t"
#endif // PbarP

#if PapgH
	"m.h.baro\t"
#endif // PapgH
#if PapgP
	"m.max.apg\tt.max.apg\t"
#endif // PapgP
#if PapgA
	"alpha.apg\t"
#endif // PapgA
#if PapgS
	"sigma.apg\t"
#endif // PapgS
#if PapgM
	"max.sigma.apg\t"
#endif // PapgM

#if Pgps
	"Lat.GPS\tLon.GPS\tm.h.GPS\tmps.GPS\tsat.GPS\tprec.GPS\t"
#endif // Pgps

#if PbarT || PbarP || PaclX || PaclY || PaclZ || PgirX || PgirY || PgirZ || PmagX || PmagY || PmagZ || PapgW || PapgH || PapgP || PapgA || PapgS || PapgM || Pgps || Psep || Tcom || Lcom || PERF_Tcom_print
));
#endif // PbarT || PbarP || PaclX || PaclY || PaclZ || PgirX || PgirY || PgirZ || PmagX || PmagY || PmagZ || PapgW || PapgH || PapgP || PapgA || PapgS || PapgM || Pgps || Psep || Tcom || Lcom || PERF_Tcom_print
/*
#if PbarT || PbarP || PaclX || PaclY || PaclZ || PgirX || PgirY || PgirZ || PmagX || PmagY || PmagZ || PapgW || PapgH || PapgP || PapgA || PapgS || PapgM || Pgps || Psep || Tcom || Lcom || PERF_Tcom_print
	Serial.println(F(
#endif // PbarT || PbarP || PaclX || PaclY || PaclZ || PgirX || PgirY || PgirZ || PmagX || PmagY || PmagZ || PapgW || PapgH || PapgP || PapgA || PapgS || PapgM || Pgps || Psep || Tcom || Lcom || PERF_Tcom_print
#if Lcom
	"\t"
#endif // Lcom

#if PERF_Tcom_print
	"s\t"
#endif // PERF_Tcom_print

#if Tcom
	"s\t"
#endif // Tcom


#if PaclX
	"X\t"
#endif // PaclX
#if PaclY
	"Y\t"
#endif // PaclY
#if PaclZ
	"Z\t"
#endif // PaclZ


#if PgirX
	"X\t"
#endif // PgirX
#if PgirY
	"Y\t"
#endif // PgirY
#if PgirZ
	"Z\t"
#endif // PgirZ


#if PmagX
	"X\t"
#endif // PmagX
#if PmagY
	"Y\t"
#endif // PmagY
#if PmagZ
	"Z\t"
#endif // PmagZ


#if PbarT
	"C\t"
#endif // PbarT
#if PbarP
	"Pascal\t"
#endif // PbarP

#if PapgH
	"m\t"
#endif // PapgH
#if PapgP
	"Max h\tMax t\t"
#endif // PapgP
#if PapgA
	"Alpha\t"
#endif // PapgA
#if PapgS
	"Sigma\t"
#endif // PapgS
#if PapgM
	"Max S\t"
#endif // PapgM

#if Pgps
	"Latitude\tLongitude\tAltitude\tSpeed (m/s)\tSat\tPrec\t"
#endif // Pgps

#if PbarT || PbarP || PaclX || PaclY || PaclZ || PgirX || PgirY || PgirZ || PmagX || PmagY || PmagZ || PapgW || PapgH || PapgP || PapgA || PapgS || PapgM || Pgps || Psep || Tcom || Lcom || PERF_Tcom_print
	));
#endif // PbarT || PbarP || PaclX || PaclY || PaclZ || PgirX || PgirY || PgirZ || PmagX || PmagY || PmagZ || PapgW || PapgH || PapgP || PapgA || PapgS || PapgM || Pgps || Psep || Tcom || Lcom || PERF_Tcom_print
*/

#if SDCard
	SDC.util.begin();
#endif // SDCard

	////////////////WUF directive////////////////

#if WUF
	WaitUntilFlight(CURRENT_MODE_WUFheigh);
#if COMmode
	transmit(F("LiftOff confirmed"));
#endif // COMmode
#endif // WUF

	////////////////WUF directive////////////////

	Gutil.begin();

#if LoRamode
	LRutil.begin();
#endif // LoRamode

#if ApoGee
	apg.resetTimer();
#endif // ApoGee
#if AnyDeploy
	rec.resetTimer();
#endif // AnyDeploy

#if WUPS
	WaitUntilPressureStabilize(CURRENT_MODE_WUPSdelay);
#if COMmode
	transmit(F("Pressure Stabilize timer expired"));
#endif // COMmode
#endif // WUPS

}
#pragma endregion

/////////////////////////////////////////////////////LOOP//////////////////////////////////////////////////////

#pragma region Loop
void loop()
{
#if RBF || WUF || ForceSysC
	sysC = 0;
#endif // RBF || WUF || ForceSysC

	Gutil.counter();
	readEverything();

#if ApoGee
	if(baroHasData) apg.calcHeight(baro.getPressure());
#if AnyDeploy
	rec.emergency(baro.getTimeLapse() > 1000000 * LapsMaxT);
	if (rec.getGlobalState())
	{
		apg.apgSigma();
		apg.apgAlpha();
		rec.sealApogee(apg.getApogeu(0.8f));
		rec.putHeight(apg.getHeight());
		rec.refresh();
#if PapgM
		Gutil.comparer(apg.getSigma());
#endif // PapgM
		if (rec.getApogee()) Gutil.mem = 1;
	}
	else {
#if MORSE_MSG
		if(Mutil.oneTime())
		{
			mensageiro.msgAux = F(". ~ . ^ . < . = . > . [ . ] . { . } A ");
			mensageiro.msgAux += String(apg.getApgPt());
			mensageiro.msgAux += F(" m");
			mensageiro.setNextMessage(mensageiro.msgAux);
			mensageiro.msgAux = "";
		}
		mensageiro.updateMorse();
#endif // MORSE_MSG
#if BEEPING
		beep(SYSTEM_n); //rec
#endif // BEEPING
	}
#endif // AnyDeploy
#endif // ApoGee
#if PWMapg
	analogWrite(PWMout, (char)(apg.getSigma() * 255));
#endif // PWMapg

#if ((PRINT) || (PERF_Tcom_print))
	SerialSend();
#endif // ((PRINT) || (PERF_Tcom_print))

#if SDCard
	SDSend();
#endif // SDCard

#if LoRamode
	LoRaSend();
#endif // LoRamode

#if MORSE_MSG && ForceSysC
	mensageiro.updateMorse();
#endif // MORSE_MSG
#if BEEPING && ForceSysC
	beep(sysC);
#elif BEEPING && !WUF && !RBF && !ApoGee
	beep(1);
#endif // BEEPING && !WUF && !RBF && !ApoGee
}
#pragma endregion

//////////////////////////////////////////////////////RBF//////////////////////////////////////////////////////

#if RBF
inline void RemoveBefore()
{
	bool rbf = 0;
	Helpful rbfHelper;
	do
	{
		sysC = 0;
		readEverything();
		rbf = digitalRead(RBFpin);
		if (rbfHelper.oneTime())
		{
#if PRINT
			Serial.print(sysC);
			Serial.print(F(" parts of "));
			Serial.print(SYSTEM_n);
			Serial.print(F(" working, waiting...\t"));
#if USE_BARO
			Serial.print(baro.getTemperature());
			Serial.print(F(" "));
			Serial.write(0xB0);
#endif // USE_BARO
#if GPSmode
			Serial.print(F("C\tLat: "));
			Serial.print(GpS.getLatitude(), 6);
			Serial.print(F("\tLon: "));
			Serial.print(GpS.getLongitude(), 6);
			Serial.print(F("\t"));
			Serial.print(GpS.getDay());
			Serial.print('/');
			Serial.print(GpS.getMonth());
			Serial.print('\t');
			Serial.print(GpS.getHour());
			Serial.print(':');
			Serial.print(GpS.getMinute());
			Serial.print(':');
			Serial.print(GpS.getSecond());
#endif // GPSmode

			Serial.println();

#endif // PRINT
		}
		else if (rbfHelper.eachT(2)) rbfHelper.oneTimeReset();
#if LoRamode
		LoRaSend();
#endif // LoRamode

#if BuZZ
		///////////////////////////////////////

		beep(sysC);

		///////////////////////////////////////

#endif // BuZZ

	} while (!rbf);
#if BuZZ
	beep();
#endif // BuZZ
}
#endif // RBF

//////////////////////////////////////////////////////WU//////////////////////////////////////////////////////

#if WU
inline void WaitUntil()
{
	sysC = 0;
	#if MORSE_MSG
		if(!mensageiro.getQuiet()) mensageiro.msgAux = "";
	#endif // MORSE_MSG
			Gutil.counter();
			readEverything();

	#if ApoGee
			if(baroHasData) apg.calcHeight(baro.getPressure());
			apg.apgSigma();
			apg.apgAlpha();
	#if PapgM
			Gutil.comparer(apg.getSigma());
	#endif // PapgM
	#endif // ApoGee
	#if PWMapg
			analogWrite(PWMout, (char)(apg.getSigma() * 255));
	#endif // PWMapg

	#if ((PRINT) || (PERF_Tcom_print))
			SerialSend();
	#endif // ((PRINT) || (PERF_Tcom_print))

	#if SDCard
			SDSend();
	#endif // SDCard

	#if LoRamode
			LoRaSend();
	#endif // LoRamode
}
#endif // WU

#if WUF
inline void WaitUntilFlight(float minHeight)
{
	do
	{
		WaitUntil();

#if MORSE_MSG
		// if(Mutil.oneTime()) if(mensageiro.msgAux.length() > 0) mensageiro.setNextMessage("= "+mensageiro.msgAux);
		// if(mensageiro.updateMorse()) Mutil.oneTimeReset();

		if(mensageiro.msgAux.length() > 0) { // Any system failed
			if(Mutil.oneTime()) mensageiro.setNextMessage("= "+mensageiro.msgAux);
			if(mensageiro.updateMorse()) Mutil.oneTimeReset();
		} else { // No system failed
			if(!mensageiro.getQuiet())
			{
				if(mensageiro.updateMorse()) // After sound sequence completed
				{
					mensageiro.setQuiet(); // Mute sound
					Mutil.forT(ALARM_DELAY); // Wait some time
				}
			}
			else {
				if(!Mutil.forT()) mensageiro.updateMorse(); // Restart sound
			}
		}
#endif // MORSE_MSG
#if BEEPING
		beep(sysC);
#endif // BEEPING

	}
	while (abs(apg.getHeight()) < minHeight && !(baro.getTimeLapse() > 1000000 * LapsMaxT));
#if MORSE_MSG
	mensageiro.setQuiet();
	Mutil.oneTimeReset();
#endif // MORSE_MSG
#if BEEPING
	beep();
#endif // BEEPING
}
#endif // WUF

#if WUPS
inline void WaitUntilPressureStabilize(float waitTime) {
	Gutil.forT(waitTime);
	while (Gutil.forT())
	{
		WaitUntil();
	}
	// Ensure that apogee point was not given during pressure anomaly
	apg.resetAptPt();
}
#endif // WUPS

//////////////////////////////////////////////////////SPT//////////////////////////////////////////////////////

#if ((PRINT) || (PERF_Tcom_print))
inline void SerialSend()
{

#if Ncom
	if (Gutil.eachN(100))
	{
		Serial.print(Gutil.getCount());
		Serial.print('\t');
		float T = Gutil.lapse();
		Serial.print(T, 5);
		Serial.print('\t');
		Serial.println(1 / T, 5);
	}
	else
	{
		Gutil.lapse();
	}
#endif // Ncom

#if Lcom
	Serial.print(Gutil.getCount());
	Serial.print(F(":\t"));
#endif // Lcom

#if PERF_Tcom_print // Print elapsed iteration time every 100 iterations, for performance tests only
	static Helpful G;
	static float a;

	float b= Gutil.sinceBegin();

	//Serial.print((b-a)*500, 3);
	if ((b - a) * 100 > 1) Serial.println(G.lapse(),6);
	else G.lapse();
	a = b;
#endif // PERF_Tcom_print

#if Tcom
	Serial.print(Gutil.sinceBegin());
	Serial.print('\t');
#endif // Tcom

	////////////////////////////////////////////////////
#if Psep && (PaclX || PaclY || PaclZ)
	Serial.print('|');
#endif // Psep && (PaclX || PaclY || PaclZ)
#if PaclX
	Serial.print(MM_accel[0], 3);
	Serial.print('\t');
#endif // PaclX

#if PaclY
	Serial.print(MM_accel[1], 3);
	Serial.print('\t');
#endif // PaclY

#if PaclZ
	Serial.print(MM_accel[2], 3);
	Serial.print('\t');
#endif // PaclZ

	/////////////////////////////////////////////////////
#if Psep && (PgirX || PgirY || PgirZ)
	Serial.print('|');
#endif // Psep && (PgirX || PgirY || PgirZ)
#if PgirX
	Serial.print(MM_giro[0], 1);
	Serial.print('\t');
#endif // PgirX

#if PgirY
	Serial.print(MM_giro[1], 1);
	Serial.print('\t');
#endif // PgirY

#if PgirZ
	Serial.print(MM_giro[2], 1);
	Serial.print('\t');
#endif // PgirZ

	////////////////////////////////////////////////////
#if Psep && (PmagX || PmagY || PmagZ)
	Serial.print('|');
#endif // Psep && (PmagX || PmagY || PmagZ)
#if PmagX
	Serial.print(MM_magn[0], 1);
	Serial.print('\t');
#endif // PmagX
#if PmagY
	Serial.print(MM_magn[1], 1);
	Serial.print('\t');
#endif // PmagY
#if PmagZ
	Serial.print(MM_magn[2], 1);
	Serial.print('\t');
#endif // PmagZ

	////////////////////////////////////////////////////
#if Psep && (PbarT || PbarP)
	Serial.print('|');
#endif // Psep && (PbarT || PbarP)
#if PbarT
	Serial.print(MM_baro[0], 1);
	Serial.print('\t');
#endif // PbarT
#if PbarP
	Serial.print(MM_baro[1], 1);
	Serial.print('\t');
#endif // PbarP

	/////////////////////////////////////////////////////
#if Psep && PapgH
	Serial.print('|');
#endif // Psep && PapgH
#if PapgH
	Serial.print(apg.getHeight());
	Serial.print('\t');
#endif // PapgH

#if Psep && PapgP
	Serial.print('|');
#endif // Psep && PapgP
#if PapgP
	Serial.print(apg.getApgPt());
	Serial.print('\t');
	Serial.print(apg.getApgTm());
	Serial.print('\t');
#endif // PapgP

#if Psep && (PapgA || PapgS)
	Serial.print('|');
#endif // Psep
#if PapgA
	Serial.print(apg.getAlpha());
	Serial.print('\t');
#endif // PapgA
#if PapgS
	Serial.print(apg.getSigma(), 7);
	Serial.print('\t');
#endif // PapgS


	/////////////////////////////////////////////////////
#if Psep && PapgM
	Serial.print('|');
#endif // Psep && PapgM
#if PapgM
	Serial.print(Gutil.getMax(), 5);
	Serial.print('\t');
#endif // PapgM



#if Pgps
#if Psep
	Serial.print('|');
#endif // Psep
	Serial.print(GpS.getLatitude(), 6);
	Serial.print('\t');
	Serial.print(GpS.getLongitude(), 6);
	Serial.print('\t');
	Serial.print(GpS.getAltitude());
	Serial.print('\t');
	Serial.print(GpS.getMps(), 3);
	Serial.print('\t');
	Serial.print(GpS.getSatellites());
	Serial.print('\t');
	Serial.print(GpS.getPrecision());
	Serial.print('\t');
	Serial.print(GpS.getChars());
	Serial.print('\t');
	Serial.print(GpS.getYear());
	Serial.print('-');
	Serial.print(GpS.getMonth());
	Serial.print('-');
	Serial.print(GpS.getDay());
	Serial.print('\t');
	Serial.print(GpS.getHour());
	Serial.print(':');
	Serial.print(GpS.getMinute());
	Serial.print(':');
	Serial.print(GpS.getSecond());
	Serial.print('\t');
	Serial.print(GpS.getKph());
	Serial.print('\t');
	Serial.print(GpS.getMps());
	Serial.print('\t');
#endif // Pgps
#if PapgW
	if (Gutil.mem)
	{
		Serial.print(F("H: "));
		Serial.print(apg.getApgPt());
		Serial.print(F(" m\tT:"));
		Serial.print(apg.getApgTm());
		Serial.print(F(" s\t"));
	}
#if COMmode
#if AnyDeploy
	if (rec.getGlobalState())
	{
		if (rec.mainN.getState(0))
		{
#if SDCard
			rec.mainN.getStateReset(); // Serial -> SD -> LoRa
#endif // SDCard
			Serial.print(F("Act MainN:"));
			Serial.print(rec.mainN.getDeploymentHeight());
			Serial.print(F("m\t"));
		}

#if DualDeploy
		if (rec.drogN.getState(0))
		{
#if SDCard
			rec.drogN.getStateReset(); // Serial -> SD -> LoRa
#endif // SDCard
			Serial.print(F("Act DrogueN:"));
			Serial.print(rec.drogN.getDeploymentHeight());
			Serial.print(F("m\t"));
		}
#endif // DualDeploy

#if BackupDeploy
		if (rec.mainB.getState(0))
		{
#if SDCard
			rec.mainB.getStateReset(); // Serial -> SD -> LoRa
#endif // SDCard
			Serial.print(F("Act MainB:"));
			Serial.print(rec.mainB.getDeploymentHeight());
			Serial.print(F("m\t"));
		}

#if DualDeploy
		if (rec.drogB.getState(0))
		{
#if SDCard
			rec.drogB.getStateReset(); // Serial -> SD -> LoRa
#endif // SDCard
			Serial.print(F("Act DrogueB:"));
			Serial.print(rec.drogB.getDeploymentHeight());
			Serial.print(F("m\t"));
		}

#endif // DualDeploy
#endif // BackupDeploy
	}
#endif // AnyDeploy
#endif // COMmode

#endif // PapgW

#if PbarT || PbarP || PaclX || PaclY || PaclZ || PgirX || PgirY || PgirZ || PmagX || PmagY || PmagZ || PapgW || PapgH || PapgP || PapgA || PapgS || PapgM || Pgps || Psep || Tcom || Lcom
	Serial.println();
#endif // PbarT || PbarP || PaclX || PaclY || PaclZ || PgirX || PgirY || PgirZ || PmagX || PmagY || PmagZ || PapgW || PapgH || PapgP || PapgA || PapgS || PapgM || Pgps || Psep || Tcom || Lcom

}
#endif // ((PRINT) || (PERF_Tcom_print))

//////////////////////////////////////////////////////SDC//////////////////////////////////////////////////////

#if SDCard
inline void SDSend()
{
	if (!SDC.util.mem)
	{
		if (SDC)
		{
			SDC.theFile.print(SDC.util.sinceBegin(), 3); SDC.tab();
#if USE_ACCEL
			for (short i = 0; i < 3; i++) { SDC.theFile.print(MM_accel[i], 3);	SDC.tab(); }
#endif // USE_ACCEL
#if USE_GYRO
			for (short i = 0; i < 3; i++) { SDC.theFile.print(MM_giro[i], 1);	SDC.tab(); }
#endif // USE_GYRO
#if USE_MAGN
			for (short i = 0; i < 3; i++) { SDC.theFile.print(MM_magn[i], 1);	SDC.tab(); }
#endif // USE_MAGN
#if USE_BARO
			for (short i = 0; i < 2; i++) { SDC.theFile.print(MM_baro[i]);		SDC.tab(); }
#if ApoGee
			SDC.theFile.print(apg.getHeight()); SDC.tab();
#endif // ApoGee

#endif // USE_BARO

#if GPSmode
			if (GpS.isNew())
			{
				SDC.theFile.print(GpS.getLatitude(), 6);	SDC.tab(); //Latitude
				SDC.theFile.print(GpS.getLongitude(), 6);	SDC.tab(); //Longitude
				SDC.theFile.print(GpS.getAltitude());		SDC.tab(); //Altitude
				SDC.theFile.print(GpS.getMps());			SDC.tab(); //Velocidade
				SDC.theFile.print(GpS.getSatellites());		SDC.tab(); //Numero de satelites
				SDC.theFile.print(GpS.getPrecision());		SDC.tab(); //Precisao
			}
			else
			{
				SDC.tab();
				SDC.tab();
				SDC.tab();
				SDC.tab();
				SDC.tab();
				SDC.tab();
			}
#endif // GPSmode

#if ApoGee
			//if (apg.getApogeu(0.9, 0))
			if (Gutil.mem)
			{
				if (SDC.util.oneTime())
				{
					SDC.theFile.print(F("H:"));
					SDC.theFile.print(apg.getApgPt());
					SDC.theFile.print(F(" m\tT:"));
					SDC.theFile.print(apg.getApgTm());
					SDC.theFile.print(F(" s"));
					SDC.tab();
				}
#if AnyDeploy
				if (rec.mainN.getState(0))
				{
#if LoRamode
					rec.mainN.getStateReset(); // Serial -> SD -> LoRa
#endif // LoRamode
					SDC.theFile.print(F("Act MainN:"));
					SDC.theFile.print(rec.mainN.getDeploymentHeight());
					SDC.theFile.print(F("m\t"));
				}

#if DualDeploy
				if (rec.drogN.getState(0))
				{
#if LoRamode
					rec.drogN.getStateReset(); // Serial -> SD -> LoRa
#endif // LoRamode
					SDC.theFile.print(F("Act DrogueN:"));
					SDC.theFile.print(rec.drogN.getDeploymentHeight());
					SDC.theFile.print(F("m\t"));
				}
#endif // DualDeploy

#if BackupDeploy
				if (rec.mainB.getState(0))
				{
#if LoRamode
					rec.mainB.getStateReset(); // Serial -> SD -> LoRa
#endif // LoRamode
					SDC.theFile.print(F("Act MainB:"));
					SDC.theFile.print(rec.mainB.getDeploymentHeight());
					SDC.theFile.print(F("m\t"));
				}

#if DualDeploy
				if (rec.drogB.getState(0))
				{
#if LoRamode
					rec.drogB.getStateReset(); // Serial -> SD -> LoRa
#endif // LoRamode
					SDC.theFile.print(F("Act DrogueB:"));
					SDC.theFile.print(rec.drogB.getDeploymentHeight());
					SDC.theFile.print(F("m\t"));
				}
#endif // DualDeploy

#endif // BackupDeploy

#endif // AnyDeploy

			}
#endif // ApoGee
			SDC.theFile.println();
			SDC.close();
#if RBF || WUF || ForceSysC
			sysC++;
#endif // RBF || WUF || ForceSysC

		}
		else
		{
			SDC.util.mem = 1;
#if MORSE_MSG
			if(!mensageiro.getQuiet()) mensageiro.msgAux += " S"; // ...
#endif  // MORSE_MSG
		}
	}
	else{
		if (SDC.util.eachT(15)) if (SDC.begin()) SDC.util.mem = 0;
		#if MORSE_MSG
			if(!mensageiro.getQuiet()) mensageiro.msgAux += " S"; // ...
		#endif  // MORSE_MSG
	}
}
#endif // SDCard

//////////////////////////////////////////////////////BZZ//////////////////////////////////////////////////////

#if BEEPING
inline void beep(unsigned int N)
{
	if (beeper.eachT(holdT*SYSTEM_n * 4) || beeper.oneTime())
	{
		beeper.mem = buzzCmd;
		beeper.counterReset();
		beeper.forT(holdT);
	}
	if (beeper.getCount() < (N + 1) * 2) if (!beeper.forT())
	{
		digitalWrite(buzzPin, beeper.mem);
		beeper.mem = !beeper.mem;
		beeper.counter();
		beeper.forT(holdT);
	}
}

inline void beep()
{
	digitalWrite(buzzPin, !buzzCmd);
	beeper.counterReset();
}
#endif // BEEPING

//////////////////////////////////////////////////////LRM//////////////////////////////////////////////////////

#if LoRamode
inline void LoRaSend()
{
	/*
	L - Line
	T - Time
	A - Latitude
	O - Longitude
	h - horas
	n - minutos
	g - precisão
	H - altura atual
	s - SD
	a - altura Apogeu
	t - tempo Apogeu
	M - Main Normal
	D - Drogue Normal
	m - Main Backup
	d - Drogue Backup
	c - Temperatura
	*/
	if (LRutil.eachT(LoRaDelay))
	{
		LoRa.println();
#if USE_LoRa_KEYVALUE
		LoRa.print(F(LoRa_KEY_LINE)); // >>L<<ine
#endif // USE_LoRa_KEYVALUE
		LoRa.print(LRutil.counter());
		LoRa.print('\t');
#if USE_LoRa_KEYVALUE
		LoRa.print(F(LoRa_KEY_TIME)); // >>T<<ime
#endif // USE_LoRa_KEYVALUE
		LoRa.print(LRutil.sinceBegin());
		LoRa.print('\t');
#if GPSmode
		if(GpS.util.mem) { // Somente mandar dados validos apos primeira leitura bem sucedida
#if USE_LoRa_KEYVALUE
			LoRa.print(F(LoRa_KEY_LAT)); // l>A<titude
#endif // USE_LoRa_KEYVALUE
			LoRa.print(GpS.getLatitude(), 6);//Latitude
			LoRa.print('\t');
#if USE_LoRa_KEYVALUE
			LoRa.print(F(LoRa_KEY_LON)); // l>O<ngitude
#endif // USE_LoRa_KEYVALUE
			LoRa.print(GpS.getLongitude(), 6);//Longitude
			LoRa.print('\t');
#if USE_LoRa_KEYVALUE
			LoRa.print(F(LoRa_KEY_HOUR)); // >>h<<ora
#endif // USE_LoRa_KEYVALUE
			LoRa.print(GpS.getHour());//Hora
			LoRa.print('\t');
#if USE_LoRa_KEYVALUE
			LoRa.print(F(LoRa_KEY_MIN)); // mi>>n<<uto
#endif // USE_LoRa_KEYVALUE
			LoRa.print(GpS.getMinute());//Minuto
			LoRa.print('\t');
#if USE_LoRa_KEYVALUE
			LoRa.print(F(LoRa_KEY_PREC)); // Presicão >>g<<
#endif // USE_LoRa_KEYVALUE
			LoRa.print(GpS.getPrecision());//Precisao
			LoRa.print('\t');
		} else {
			LoRa.print(F(
#if USE_LoRa_KEYVALUE
				LoRa_KEY_LAT
#endif // USE_LoRa_KEYVALUE
				"~\t"
#if USE_LoRa_KEYVALUE
				LoRa_KEY_LON
#endif // USE_LoRa_KEYVALUE
				"~\t"
#if USE_LoRa_KEYVALUE
				LoRa_KEY_HOUR
#endif // USE_LoRa_KEYVALUE
				"~\t"
#if USE_LoRa_KEYVALUE
				LoRa_KEY_MIN
#endif // USE_LoRa_KEYVALUE
				"~\t"
#if USE_LoRa_KEYVALUE
				LoRa_KEY_PREC
#endif // USE_LoRa_KEYVALUE
				"~\t"
			));
		}
#endif // GPSmode
#if ApoGee
#if USE_LoRa_KEYVALUE
		LoRa.print(F(LoRa_KEY_HEIGTH)); // >>H<<eight
#endif // USE_LoRa_KEYVALUE
		LoRa.print(apg.getHeight());
		LoRa.print('\t');
		// LoRa.print(apg.getSigma(), 3);
		// LoRa.print('\t');
#endif // ApoGee
#if SDCard
#if USE_LoRa_KEYVALUE
		LoRa.print(F(LoRa_KEY_SD)); // >>s<<D
#endif // USE_LoRa_KEYVALUE
		LoRa.print(!SDC.util.mem);
		LoRa.print('\t');
#endif // SDCard
#if ApoGee
		if (Gutil.mem)
		{
			LoRa.print(F(LoRa_KEY_APG_HEIGHT)); // >>a<<pogee height
			LoRa.print(apg.getApgPt());
			LoRa.print(F("\t" LoRa_KEY_APG_TIME)); // apogee >>t<<ime
			LoRa.print(apg.getApgTm());
			LoRa.print('\t');
		}
#if USE_LoRa_CONTIGUOUS
	else  LoRa.print(F(
#if USE_LoRa_KEYVALUE
		LoRa_KEY_APG_HEIGHT
#endif // USE_LoRa_KEYVALUE
		"~\t"
#if USE_LoRa_KEYVALUE
		LoRa_KEY_APG_TIME
#endif // USE_LoRa_KEYVALUE
		"~\t"
	));
#endif // USE_LoRa_CONTIGUOUS
#endif // ApoGee
		//LRutil.oneTimeReset();

#if AnyDeploy
	if (
#if USE_LoRa_CONTIGUOUS
		rec.mainN.getGlobalState(1)
#else
		rec.mainN.getState(0)
#endif // USE_LoRa_CONTIGUOUS
	)
	{
		// rec.mainN.getStateReset(); // Serial -> SD -> LoRa // Último a ser realizado, não reseta
#if USE_LoRa_KEYVALUE
		LoRa.print(F(LoRa_KEY_MAIN_NORMAL)); // >>M<<ain normal
		LoRa.print(rec.mainN.getDeploymentHeight());
#else
		LoRa.print(F("Act MainN:"));
		LoRa.print(rec.mainN.getDeploymentHeight());
		LoRa.print(F("m\t"));
#endif // USE_LoRa_KEYVALUE
	}
#if USE_LoRa_CONTIGUOUS
	else  LoRa.print(F(
#if USE_LoRa_KEYVALUE
		LoRa_KEY_APG_HEIGHT
#endif // FEYVALUE
		"~\t"
	));
#endif // USE_LoRa_CONTIGUOUS

#if DualDeploy
	if (
#if USE_LoRa_CONTIGUOUS
		rec.drogN.getGlobalState(1)
#else
		rec.drogN.getState(0)
#endif // USE_LoRa_CONTIGUOUS
	)
	{
#if USE_LoRa_KEYVALUE
		LoRa.print(F(LoRa_KEY_DROGUE_NORMAL)); // >>D<<rogue normal
		LoRa.print(rec.drogN.getDeploymentHeight());
#else
		// rec.drogN.getStateReset(); // Serial -> SD -> LoRa // Último a ser realizado, não reseta
		LoRa.print(F("Act DrogueN:"));
		LoRa.print(rec.drogN.getDeploymentHeight());
		LoRa.print(F("m\t"));
#endif // USE_LoRa_KEYVALUE
	}
#if USE_LoRa_CONTIGUOUS
	else  LoRa.print(F(
#if USE_LoRa_KEYVALUE
		LoRa_KEY_DROGUE_NORMAL
#endif // USE_LoRa_KEYVALUE
		"~\t"
	));
#endif // USE_LoRa_CONTIGUOUS
#endif // DualDeploy

#if BackupDeploy
	if (
#if USE_LoRa_CONTIGUOUS
		rec.mainB.getGlobalState(1)
#else
		rec.mainB.getState(0)
#endif // USE_LoRa_CONTIGUOUS
	)
	{
#if USE_LoRa_KEYVALUE
		LoRa.print(F(LoRa_KEY_MAIN_BACKUP)); // >>m<<ain backup
		LoRa.print(rec.mainB.getDeploymentHeight());
#else
	// rec.mainB.getStateReset(); // Serial -> SD -> LoRa // Último a ser realizado, não reseta
		LoRa.print(F("Act MainB:"));
		LoRa.print(rec.mainB.getDeploymentHeight());
		LoRa.print(F("m\t"));
#endif // USE_LoRa_KEYVALUE
	}
#if USE_LoRa_CONTIGUOUS
	else  LoRa.print(F(
#if USE_LoRa_KEYVALUE
		LoRa_KEY_MAIN_BACKUP
#endif // USE_LoRa_KEYVALUE
		"~\t"
	));
#endif // USE_LoRa_CONTIGUOUS
#if DualDeploy
	if (
#if USE_LoRa_CONTIGUOUS
		rec.drogB.getGlobalState(1)
#else
		rec.drogB.getState(0)
#endif // USE_LoRa_CONTIGUOUS
	)
	{
#if USE_LoRa_KEYVALUE
		LoRa.print(F(LoRa_KEY_DROGUE_BACKUP)); // >>d<<rogue Backup
		LoRa.print(rec.drogB.getDeploymentHeight());
#else
		// rec.drogB.getStateReset(); // Serial -> SD -> LoRa // Último a ser realizado, não reseta
		LoRa.print(F("Act DrogueB:"));
		LoRa.print(rec.drogB.getDeploymentHeight());
		LoRa.print(F("m\t"));
#endif // USE_LoRa_KEYVALUE
	}
#if USE_LoRa_CONTIGUOUS
	else  LoRa.print(F(
#if USE_LoRa_KEYVALUE
		LoRa_KEY_DROGUE_BACKUP
#endif // USE_LoRa_KEYVALUE
		"~\t"
	));
#endif // USE_LoRa_CONTIGUOUS
#endif // DualDeploy
#endif // BackupDeploy

#endif // AnyDeploy
#if USE_BARO
#if USE_LoRa_KEYVALUE
		LoRa.print(F(LoRa_KEY_TEMPERATURE)); // >>c<< temperatura
#endif // USE_LoRa_KEYVALUE
		LoRa.print(baro.getTemperature());
		LoRa.print('\t');
#endif // USE_BARO
  }
}
#endif // LoRamode

//////////////////////////////////////////////////////COM//////////////////////////////////////////////////////

#if COMmode
template <typename T> void transmit(T message)
{
#if PRINT
	Serial.print(message);
#endif // PRINT
#if LoRamode
	LoRa.print(message);
#endif // LoRamode
}

template <typename T> void transmitln(T message)
{
#if PRINT
	Serial.println(message);
#endif // PRINT
#if LoRamode
	LoRa.println(message);
#endif // LoRamode
}

template <typename T, typename R> void transmit(T message, R value)
{
#if PRINT
	Serial.print(message, value);
#endif // PRINT
#if LoRamode
	LoRa.print(message, value);
#endif // LoRamode
}

template <typename T, typename R> void transmitln(T message, R value)
{
#if PRINT
	Serial.println(message, value);
#endif // PRINT
#if LoRamode
	LoRa.println(message, value);
#endif // LoRamode
}

#endif // COMmode

//////////////////////////////////////////////////////RET//////////////////////////////////////////////////////

inline void readEverything()
{
#if USE_BARO
	if (baro)
	{
		MM_baro[0] = baro.getTemperature();
		MM_baro[1] = baro.getPressure();
#if RBF || WUF || ForceSysC
		sysC++;
#endif // RBF || WUF || ForceSysC
		baroHasData = true;
	} else {
#if MORSE_MSG
		if(!mensageiro.getQuiet()) mensageiro.msgAux += " B"; // -...
		baroHasData = false;
#endif  // MORSE_MSG
	}
#endif // USE_BARO
#if USE_ACCEL
	if (accel)
	{
		MM_accel[0] = accel.getX();
		MM_accel[1] = accel.getY();
		MM_accel[2] = accel.getZ();
#if RBF || WUF || ForceSysC
		sysC++;
#endif // RBF || WUF || ForceSysC
	} else {
#if MORSE_MSG
		if(!mensageiro.getQuiet()) mensageiro.msgAux += " A"; // .-
#endif  // MORSE_MSG
	}
#endif // USE_ACCEL
#if USE_GYRO
	if (giro)
	{
		MM_giro[0] = giro.getX();
		MM_giro[1] = giro.getY();
		MM_giro[2] = giro.getZ();
#if RBF || WUF || ForceSysC
		sysC++;
#endif // RBF || WUF || ForceSysC
	} else {
#if MORSE_MSG
		if(!mensageiro.getQuiet()) mensageiro.msgAux += " G"; // --.
#endif  // MORSE_MSG
	}
#endif // USE_GYRO
#if USE_MAGN
	if (magn)
	{
		MM_magn[0] = magn.getX();
		MM_magn[1] = magn.getY();
		MM_magn[2] = magn.getZ();
#if RBF || WUF || ForceSysC
		sysC++;
#endif // RBF || WUF || ForceSysC
	} else {
#if MORSE_MSG
		if(!mensageiro.getQuiet()) mensageiro.msgAux += " M"; // --
#endif  // MORSE_MSG
	}
#endif // USE_MAGN
#if GPSmode
	if (GpS) GpS.util.forT(10);
	if (!GpS.util.mem) if (GpS.isNew()) GpS.util.mem = true; // Auxiliar de primeira leitura bem sucedida
	if (GpS.util.forT()) {
#if RBF || WUF || ForceSysC
		sysC++;
#endif // RBF || WUF || ForceSysC
	} else {
#if MORSE_MSG
		if(!mensageiro.getQuiet()) mensageiro.msgAux += " L"; // .-..
#endif  // MORSE_MSG
}

#endif // GPSmode
#if AnyDeploy && (RBF || WUF)
	if (rec.mainN.info()) {
		sysC++;
	} else {
#if MORSE_MSG
		if(!mensageiro.getQuiet()) mensageiro.msgAux += " Rmn"; // .-. -- -.
#endif  // MORSE_MSG
	}

#if DualDeploy
	if (rec.drogN.info()) {
		sysC++;
	} else {
#if MORSE_MSG
		if(!mensageiro.getQuiet()) mensageiro.msgAux += " Rdn"; // .-. -.. -.
#endif  // MORSE_MSG
	}
#endif // DualDeploy


#if BackupDeploy
	if (rec.mainB.info()) {
		sysC++;
	} else {
#if MORSE_MSG
		if(!mensageiro.getQuiet()) mensageiro.msgAux += " Rmb"; // .-. -- -...
#endif  // MORSE_MSG
	}

#if DualDeploy
	if (rec.drogB.info()) {
		sysC++;
	} else {
#if MORSE_MSG
		if(!mensageiro.getQuiet()) mensageiro.msgAux += " Rdb"; // .-. -.. -...
#endif  // MORSE_MSG
	}
#endif // DualDeploy

#endif // BackupDeploy

#endif // AnyDeploy && (RBF || WUF)
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#if 0
/*
 *                                                                           I8$$$????$?????????$??????$$?8+
 *                                                                    $$$$?????????????????????????????????????$?$$
 *                                                              +?$???????????????????????????????????????????????????$$:
 *                                                          ?????????????????????$?$??$O???????$$$$????$?????????????????????
 *                                                      $$????????????????$$?,           ?????$$           ,$$$??????????????$$$I
 *                                                  ,$8?????????????$$,                  ?????$$                   $$$????????????$?
 *                                                $?????????????8                        ?????$$                        $?????????????$
 *                                             8??$????????$$                            ?????$$                            $$?????????$??
 *                                          +8??????????$                                ?????$$                               :$?????????I$,
 *                                        $8?????????$                                   ??????$                                   $???????$?$?
 *                                      $?????????$                              I$8$$????????$$????8$?+                             ,$????????$$
 *                                    $????????$8                          88???????????????????????????????88:                         $$????????8
 *                                  $???????$?,                      I$$???????????????????????$$$$????????????????+                      =?$????????
 *                                $?????$$?$                     $???????????????$?????????????,  $????????????????????$                     ?$$??????$
 *                              8$???????$                   ?$????????$$???????????????    ???   ?$I$$???????????????????8+                   $??????$$?
 *                            =$$??????$                  $??????$$=      $???     $?$   $?  I?   ?   $?$I   $???????$$??$?$?$I                  $$?????$?,
 *                           $???????8                 I$???????$I  =8$,  $??  $?   $$  ???????      $??   8I  8?$$   ?????????$?~                 8????????
 *                         $$$??????                 8$???????????   8,  :$?$  ??$  $$   $?  ~?   $   $$       ~?     $???????????I8                 ????????I
 *                        $???????:               ?$??????????????:        ??       ??$I    8?$  I?I  I$  8?$8?$?8  ~ ???????$:8????$$~               +$?$????8
 *                      ~??????$$               $????$8+ 8????????8   ?$    I$$??$$$????????????????????$~    =?$   $????????I   ~$????$+               8??????$
 *                     $?????????$+           $$?????     $?$???????  ????$????????????$?????????$??????????????$   $???????:   ,  :$?????+            $?????????$
 *                    $????????????$        =$???$?$  $$???$$??????$ ?$?????$????$$$$I,           :?$$$????$?????$? 8??????~   ??8  +??????$,        8????????????$
 *                   ??????????????$?8     ?$$?????   $?$??  $?????$????????$I                             I$??????$$$????,   $?$   +????????$     =$???????????????
 *                 ,$?????$  $?????????  8??????????   $??8  $?????????$$=                                     I8????????8   ?$??   $?????????$?  8$????????+~$??????
 *               ?$?????$     $??????????$??    $??        ,$??????$?                                             $???????$       ?$$$8????????$$????????8    ???????,
 *               ???????$       ???????????I     ?8$?8     $$???$?,                                                   +$?????8$,:$?8      $??????????????      ,???????
 *             ,8?????$O          O?????$8   $$,   ,+?????????$~                                                         I???$?????    $$  ???????????$          ??????$=
 *             +??????8            =?????$      $$   ?????$??                                                               ???????  ?O    $????????$I            ???????
 *            ???????$            8????????,   ,$?  8????$$                                                                   $????$   8? 8?$$$???????$            8?????$
 *            $?????$            I$?????????$      ?$???$ ,                                                                     $?????~ =$?I   ,$??????$            $???$?$
 *           ???????            $?$?$  ??????$=  8????$                                    $8:                                    $????$? ?$  ?  ???????$            $?????$
 *          $?????$            $???8         8$$$???$:                                    :O88~                                    $$????, $=  8 $???$???$            $?????$
 *         $$????$            $????I   $I~    $$???8                 8                    O8888                          =           8???$  :  ????$  ????$            $?????8
 *        I??????            8??????$   8  $?8???$,                 OO                   ?888888                        ,8            ?$???8  ?$?+  8 $$???$           ,??????
 *        ?????$~           $???~=????    $$?????,                  + O                  8888888                       ?888~           +?$???I$~    ?$??????I           ??????$
 *       ???????           $???8  $??I?   ??????                                        =88888888                       888              ?$??$    ????????????           ??????8
 *      ~?????$           ,???$  $$  8?$  ?$??8                                         88888888O                                         ?????I??$    $??????            $?????
 *      ??????:           $??$   I  ?$???$????                                          888888888                                          $???$8       $?????$           ??????$
 *     $??????           $???$      ?$$?????8                                           888888888                                           $?  $  ??$ +,??????$           $?????+
 *     $?????           ???????$?      ???$8                                            888888888,                                           8? $?~ ,    ???????           ?$$???$
 *    ?$????$           $??$ 8$$???? ,+???$                                             888888888~                                            ?,       $????????$           $$????,
 *    ??????           ????      ~????????            ~O                                888888888?                                             $= , $???$  ??????$          ,$????$
 *   $??????$?         ????$$=     ,????$                                               888888888?         =O                                  ????$I      ???????         $$??????:
 *   ??????????$      $?$????$?$$~ ,$?$??                                               888888888?                                              $????  ,$?  ??????$     ~$??????????
 *   $????????????$   ??$?  ?$???8  ????                                                888888888?                                               $??$$??$:  ??????$  :$?????????????
 *  $???????????????$$???          ????=                                                888888888$                                               $??$I      $??????$$???????????????:
 *  $????????????????????$$$      +????                                  OO             888888888$                          =                     ???$   8$$??????????????????:?????$
 *  $????$ $???????????????????$??????8                                                 888888888$                        8888=                   $??????????????????????$$    ?????$
 * I??????    $$??????????????????????                                                  888888888$                         OO?                     ????????????????????$~      $?????
 * $?????       :$$?$????????????????$                                                  888888888$                                                 $?????????????????I         +??????
 * ??????           ?????????????????,                                                  8888,$888$                                                 $?????????????????           ?????$
 * ?????$          +????????????????$                                                 ? 8888 8888$$                                                 ?????????????????           ??????
 * ??????          $????????????????$                                                 8,8888 8888$8?                                                ?????????????????=          $????$
 * ?????8          $????????????????$                                                88:8888 8888$88:                                               $????????????????$          8????$
 * ?????$          $????????????????=                                               888:8888 8888$888                                               $?????????????????          $?????,
 * ?????I          ?$???????????????                                               ,888:8888 8888$8888                                              +????????????????$          ?????$+
 * ??????          ?????????????????                  :O8                          8888:8888 $888$88888                              ,,             =????????????????$          $????$I
 * ??????          ?????????????????                                              88888:8888 8888$88888                             O$:             ,$???????????????$          $??????
 * ??????          ?????????????????                                              88888:8888 8888$88888            8               $??              +????????????????$          $????$$
 * ??????          $$???????????????                                              88888 O888 $888 I8888          I8?                                =$????????????????          $????$+
 * ?????$          $????????????????~                                             888O ,? ~8,$+ :: $888                                             $?????????????????          $????$,
 * $????$          ?$??????????????$?                                             888, 888$$~88888: $88                                             $????????????????$          $?????
 * ?????$          $????????????????$                                             88?  88888?88888O ,88                                             ?????????????????+          $?????
 * ?????$          +$???????????????$                                             88   88888$88888+  ?8                                             ?????????????????           ??????
 * $?????           $????????????????                                             8    ~8888888888,   $                                            I????????????????$           ?????$
 * $?????           $????????????????8                                                 ,O8888888O$                                                 ?????????????????$          I??????
 * I??????$?$8      $?????????????????          ,$,$                                    8,O88$$==O                                                 ?????????????????$    +$?$????????
 *  ?????????$??$?$? ????????????????$8         888,               +?                  8I$88888 $O                                                ???????????????????$$?$???????????$
 *  ?$?????????????????????????????????           ,                                   8,?? 888:=?+?                       :O$                     $?????????????????????????????????$
 *  $??????????????????????????????????~                                              $$?$$$8O?8?$$                       O8OI                   $?????????????????????????????????$=
 *   ??????+$8$?????????????????????????                                              $????$$888 8$?                       ?                     ?????????????????????$??$$$  $?????
 *   ?????$,     ???$???????????????????8                                             $????$?8$$???I                                            8$?????????????????$$I        ??????
 *   $?????$           ??????????????????                                             $????$I ?????$                                           ~??????????????????           $?????=
 *    ??????           $?????????????????$                                            $????~I$?????$                                          ,$?????????????????$           ??????
 *    $$????8           $??????????????????                                           ??????????????                                          $?????????????????$           $?????=
 *     $?????           ?$?????????????????$                                         :?$????????????                                         $??????????????????:          =?????$
 *     $?????$           $??????????????????$                                        ?$?????????????:                                       ???????????????????$           $??????
 *      ??????            ????????????????????                                       ???????????????$                                      $???????????????????           ?????$$
 *      +?????$           =???????????????????8                                      ???????????????$                                     $??????????????????$            $????$
 *       ??????8           $$??????????????????$                                    $???????????????$~                                   $????????????????????           $?????$
 *        $$???$            ?????????????????????                                   $?????????????????                                  $???????????????????$           I?????$
 *        ?$???$?            $???????????????????$                                 +??????????????????                                ,????????????????????$           ,$?????~
 *         8?????$            $???????????????????$$                               $??????????????????$                              $?$??????????????????$            ??????$
 *          $?????$            $????????????????????$                             $?????????????????????                           ~?????????????????????$            $?????$
 *           ??????8            ?????????????????????$8                          ???????????????????????                          $$????????????????????$            $?????$
 *           ,$????$$            $???????????????8??????$                       +??????????????????????$$                       ?$?????????????????????$$$$$$$$$$???$??????
 *            ????????????????????????????????$$,  +$?????8                    8?????????????????????????$                    $?????????$  $??????????????????????????????=
 *             ?$?????????????????????????????8  ,?  ?$?????$                 $????????????????????????????$                $?????????? ,$  ? ???????????????????????????,
 *              8???????????????????????????$     ?  $$???????$$           ,$??????????????????????????????$??~         ????????????$~~+8 $? 8$??????????????????????????
 *               I$?????????????????????????$:+$$?, 8$??????????$?$$?$$$?$???$???????????????????????????????????????$??$?????????$?$ $??  :??$???$             $??????~
 *                8??????$             ~?????????$$  8 $$??????????????????????????????????????????????????????????????????????,8?+  ,??$$??????$              $$?????+
 *                 =???????              $???????? ,I : ?+$$???????????????????????????????????????????????????????????????????  8$$?  $???????$              $?????$
 *                  ,???????              :$?????$$ $?:OI ?$$????????????????????????????????????????????????????????$I?????$  $  ??:I8??????$              +???????:
 *                   ,?$?????$              8$??????$ $~ ~$::$??$+  $???????????????????????????????????????????????8   $??$ 8+I$   8??????8=              $??????$
 *                     ???????$               8$??????$ +???????  ? $????????????????????????????????????????????$??$ :   $$=:$  ?????????$              ,$??????8
 *                      ??????$??               8??????I$????$  ,?+ $?????????????????????????????????????????$  ???$  ?$  =$  ?$???????$               8??????$~
 *                        $????$??                ?$????????   ?,   $?   ???????????????????????????$?  $????$?  $??$    $~ :$$$?????$I                ???????$ ,
 *                         8???????$                ~$???????$$??$: $$  88$    8???$????????????????$    $?$  O$ ???$  $??$???????$$                 $???????8
 *                           ????????$                 $I?????????$ $ 8$ $= $$  $  I +$  8 ??   ?$??8 ??  $?  ??  $?? 8???????????$$$?             $???????$
 *                            ?????????I            =$??$I$$?????????$$:?$  ?8  ?     $  I??8$$ =???       ?$   ?=$???????????????????$$?        $????????+
 *                              $$$?????$?        $????$$?$$$8?$?????????$ $$ ??$ ,$$I$ :$?$ ?$ ~??$  $$?? ,$????????????$8$ $????????????$?   $???????$$
 *                                $$???????I   $???????????,    ~??$$????  $??????$$$$$+???$~ ? ,$?$?$????????????????$$,      ,$I????????????????????8
 *                                  $???????????????????8           :8$$??????????????????????????????????????????$$              ~$?????????????????
 *                                    8???????????????:                 $=?$$???????????????????????????????????$$                   ?$???????????$
 *                                     +$??????????$                   $??$?$?? ?8$??????????????????$88=  ?$??????                   8??????????
 *                                        $??????????I                ????????+           $$$????          ,8?????$$               $?????????$$
 *                                          $$?????????$$            8??????$+            $?????$            ?$?????$           $$??????$?$$?
 *                                             $??????????$$+       $??????$$             ??????$             $?????$$      I$???????????$
 *                                               =??$?$????????$=  ????????8              ???????,             $??????$ I$???????????$$
 *                                                  ?$$?$??????????????????               ???????+             ,??????????????????$?:
 *                                                      $$???????????????$?$,             ???????$          ,$$????????????????$$
 *                                                         :$????????????????$?????$$?$$I=$??????$$$$$?$???$???????????????$$,
 *                                                              $$?????????????????????????????????????????????????????$$
 *                                                                   ?$??????????????????????????????????????????$8=
 *                                                                          ?8$????????????????????????????8~
 *                                                                                    ,,+++??$+++,
 */
#endif
